<?php
	$nome = $_POST['nome'];
	$idade = $_POST['idade'];
	$termo = $_POST['aceito'];

	if ($termo != 'sim') {
		header('Location: reforco.html');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
	<div class="box">
		<h1>Bem Vindo(a)</h1>
		<p><?php echo "$nome"; ?></p>
		<hr>
		<p>Sua Idade <?php echo "$idade"; ?></p>
		<?php  
			if ($idade < 18) {
				echo "<br/>Você é menor de idade";
			}
			else{
				echo "<br/>Você é maior de idade";
			}
		?>
		<br>
		<a href="cem.php"><button>100 VEZES</button></a>
		<br>
		<a href="dez.php"><button>10 VEZES</button></a>
	</div>
</body>
</html>