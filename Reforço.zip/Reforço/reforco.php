<?php
	$nome = $_POST['nome'];
	$idade = $_POST['idade'];

	echo "$nome <br/>";
	echo "$idade";
?>