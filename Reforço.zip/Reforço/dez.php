<?php
	$i = 0;
	while ($i < 10) {
		$i++;
		echo "<br/>$i<hr>";
	}
?>