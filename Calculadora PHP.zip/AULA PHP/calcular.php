<?php
    $m = $_POST['conta'];
	$n1 = $_POST['primeiro'];
	$n2 = $_POST['segundo'];
	$op = $_POST['operação'];
	$result = 0;

	switch ($op) {
		case $op == '+':
			$result = $n1 + $n2;
			echo "$result<br/>";
			if ($m == 'mostrar'){
			echo "$n1 $op $n2 = $result";
			}
			else
			{
				echo "";
			}
			break;
		case $op == '-':
			$result = $n1 - $n2;
			echo "$result<br/>";
			if ($m == 'mostrar'){
			echo "$n1 $op $n2 = $result";
			}
			else
			{
				echo "";
			}
			break;
		case $op == 'x':
			$result = $n1 * $n2;
			echo "$result<br/>";
			if ($m == 'mostrar'){
			echo "$n1 $op $n2 = $result";
			}
			else
			{
				echo "";
			}
			break;
		case $op == '/':
			$result = $n1 / $n2;
			echo "$result<br/>";
			if ($m == 'mostrar'){
			echo "$n1 $op $n2 = $result";
			}
			else
			{
				echo "";
			}
			break;
		default:
			# code...
			break;
	}
?>